<?php 
$_con = new mysqli("localhost","root","","projecto");


?>